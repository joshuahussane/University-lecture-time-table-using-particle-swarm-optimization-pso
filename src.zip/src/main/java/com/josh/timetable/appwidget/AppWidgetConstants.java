package com.josh.timetable.appwidget;

/**
 * From https://github.com/SubhamTyagi/TimeTable
 */
final class AppWidgetConstants {

    static final int TIME_STYLE_FIRST = 0;
    static final int TIME_STYLE_SECOND = 1;
    static final int TIME_STYLE_THIRD = 2;
}
